fx_version 'adamant'

game 'gta5'

client_script "main.lua"

ui_page 'html/ui.html'

files {
	'html/ui.html',
	'html/app.js',
	'html/style.css',
	'img/seatbelt.png'
}

dependencies {
	'InteractSoundS'
}